/*
Crie uma API REST (com boas práticas, é claro!) que atenda os seguintes requisitos para os testes de produtos de uma empresa que constrói equipamentos médicos: 
1) Crie uma base de dados para armazenar os testes de produtos. As tabelas/campos a serem criados devem ser identificados ao término deste arquivo a partir do documento da "Pra-Life Equipamentos Médicos" intitulado "Fluke Biornedical Ansur / Test and Inspection Procedam,. Não é necessário contemplar todos os campos, nem todos os detalhes. Mas é importante que a solução tenha alguma relevância. A seguir, a sugestão de estrutura básica de armazenamento: 
Exemplo  de dado: 
Test Result tem: Test Record e Test Result Items

Exemplo de item Test Result:
{
    "Date":"11/05/2022",
    "Record":"IEC 60601-1 - CL1 - F7210301293.mtr",
    "Ansur": "Version 3.1.4",

    "Test Result": {
        "Test Element": 'Teste para Classe 1- P1x/R3fivhrtT4",
        "Test Type": "Auto Sequence",
        "Procedure:": "Este teste está previsto para os equipamentos ...",
    
    "Items": {
        "TAResult": "Teste Group",
        "Valse": 264.4,
        "Unit": "V",
        "HighLimit":"-",
        "LowLimit": "-", 
        "Standard": "User defined IEl 60601" 
    }
}
Obs.: a base de dados por ser em qualquer formato ou técnica, não se limitando àquelas abordados em sola de aula. 

2) A API deve ter a seguinte URI (basica) e as operações: /equipamentos 

*/

/*
GET: obtém um registro de teste a depender do código do teste, caso o código seja "O" (zero) deverá retornar todos os testes. 
POST: insere um registro de teste completo
PUT: altera um registro de teste completo
DELETE: altera um registro de teste completo 
*/
//configurações iniciais no terminal de comandos
//npm init
//npm install express  --save
//npm install cors --save
const express = require('express')
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;
let banco_testes = [
    {
        "Code": "000001",
        "Date": "11/05/2022",
        "Record": "IEC 60601-1 - CL1 - F7210301293.mtr",
        "Ansur": "Version 3.1.4",
        "Test Result": {
            "Test Element": 'Teste para Classe 1- P1x/R3fivhrtT4',
            "Test Type": "Auto Sequence",
            "Procedure:": "Este teste está previsto para os equipamentos ...",
            "Items": {
                "TAResult": "Teste Group",
                "Valse": 264.4,
                "Unit": "V",
                "HighLimit": "-",
                "LowLimit": "-",
                "Standard": "User defined IEl 60601"
            }
        }
    },
    {
        "Code": "000002",
        "Date": "12/05/2022",
        "Record": "IEC 80808-1 - CL2 - HYDUD.mtr",
        "Ansur": "Version 3.1.4",
        "Test Result": {
            "Test Element": 'Teste para Classe 2- P2i/safsaFFD',
            "Test Type": "Auto Sequence",
            "Procedure:": "Este teste está previsto para os equipamentos ...",
            "Items": {
                "TAResult": "Teste Group",
                "Valse": 373.4,
                "Unit": "V",
                "HighLimit": "-",
                "LowLimit": "-",
                "Standard": "User defined IEl 80808"
            }
        }
    }]

// Where we will keep tests
let tests = [];

app.use(cors());

// Configuring body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/test', (req, res) => {
    const test = req.body;

    let testData = {
        "Code": test.Code,
        "Date": test.Date,
        "Record": test.Record,
        "Ansur": test.Ansur,
        "Test Result": {
            "Test Element": test.TestElement,
            "Test Type": test.TestType,
            "Procedure:": test.Procedure,
            "Items": {
                "TAResult": test.TAResult,
                "Valse": test.Valse,
                "Unit": test.Unit,
                "HighLimit": test.HighLimit,
                "LowLimit": test.LowLimit,
                "Standard": test.Standard
            }
        }
    }

    // Output the test to the console for debugging
    banco_testes.push(testData);

    res.send('Test adicionado ao banco de dados');
});
// Metodo PUT para atualizar o test
app.post('/test_update/', (req, res) => {
    const test = req.body;
    let Code = test.Code;
    let testData = {
        "Code": test.Code,
        "Date": test.Date,
        "Record": test.Record,
        "Ansur": test.Ansur,
        "Test Result": {
            "Test Element": test.TestElement,
            "Test Type": test.TestType,
            "Procedure:": test.Procedure,
            "Items": {
                "TAResult": test.TAResult,
                "Valse": test.Valse,
                "Unit": test.Unit,
                "HighLimit": test.HighLimit,
                "LowLimit": test.LowLimit,
                "Standard": test.Standard
            }
        }
    }

    // Remover o teste antigo teste pelo ID
    banco_testes.splice(banco_testes.findIndex(test => test.Code === Code), 1);
    // Adicionar o teste atualizado
    banco_testes.push(testData);
    res.send('Test atualziado');
});


// Get by id
app.get('/test/:id', (req, res) => {
    const id = req.params.id;
    // Verifica se o id == 0
    if (id == 0 || id == "0") {
        res.status(200).send(banco_testes);
    }else{
        // Busca pelo id no campo Code: 
        let teste = banco_testes.find(teste => teste.Code == id);
        if (teste) {
            res.status(200).send(teste);
        }else{
            res.status(404).send('Test Não encontrado!');
        }
    }
});
// DELETE by id
app.delete('/test/:id', (req, res) => {
    let id = req.params.id;
    //res.status(200).send(`Rota DELETE com ID! --> ${id}`);
     // Busca pelo id no campo Code: 
     let teste = banco_testes.find(teste => teste.Code == id);
     if (teste) {
         // res.status(200).send(teste);
         // Apagar o registro do banco de dados pelo ID
            banco_testes = banco_testes.filter(teste => teste.Code != id);
            res.status(200).send('Test deletado!');
     }else{
         res.status(404).send('Test Não encontrado!');
     }
 });


app.listen(port, () => console.log(`Servidor rodando na porta ${port}!`));